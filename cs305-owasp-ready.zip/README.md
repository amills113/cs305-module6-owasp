# CS 305 Module Six — OWASP Dependency-Check

## Files included
- **suppression.xml** — your false-positive suppression rules
- **README.md** — overview and instructions

## How to integrate
1. In your project’s root, copy `suppression.xml` and `README.md`.
2. Open your existing `pom.xml`.
3. Find the `<plugin>` block for `dependency-check-maven` and add inside `<configuration>`:
   ```xml
   <suppressionFiles>
     <suppressionFile>suppression.xml</suppressionFile>
   </suppressionFiles>
   ```
4. Save and commit.

## How to run the scan
1. Run:
   ```bash
   mvn clean verify org.owasp:dependency-check-maven:check
   ```
2. Find the report at `target/dependency-check-report.html`.
3. To suppress issues, open the report, click **Suppress → Complete XML Doc**, copy the `<suppress>` entry into `suppression.xml`, then rerun the scan.
